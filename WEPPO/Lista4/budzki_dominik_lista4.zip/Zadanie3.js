var module = require("./zadanie3_1");
module.foo_a(5)

/*
    Mozna utworzyć cykl, w tym pliku uruchamiamy funkcje z modułu A.
    Funkcja ta korzysta z funkcji z modułu B, a funkcja z modułu B korzysta
    z funkcji z modułu A, i tak w kółko. Mamy cykl. Gdy w plikach 
    zadanie3_1.js i zadanie3_2.js zmienymi warunek if na np. true to mamy nieskończony cykl.
*/