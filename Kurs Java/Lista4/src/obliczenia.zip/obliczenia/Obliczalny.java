package obliczenia;

public interface Obliczalny {
    double oblicz();
}
