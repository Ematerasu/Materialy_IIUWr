package obliczenia;

public abstract class Operator1Arg extends Wyrazenie {
    public Wyrazenie arg;

}
