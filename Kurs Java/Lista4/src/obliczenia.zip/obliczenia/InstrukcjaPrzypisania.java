package obliczenia;
import struktury.*;

public class InstrukcjaPrzypisania extends Instrukcja{
    private Zmienna name;
    private Wyrazenie value;

    public InstrukcjaPrzypisania(Zmienna k, Wyrazenie value) {
        this.name=k;
        this.value=value;
    }

    @Override
    public void wykonaj() {
        Zmienna.zbiorZmiennych.Ustaw(new Para(name.toString(), value.oblicz()));
    }

    @Override
    public String toString() {
        return name.toString()+" = "+value.toString()+";\n";
    }
}
