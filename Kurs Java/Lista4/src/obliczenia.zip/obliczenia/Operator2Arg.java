package obliczenia;

public abstract class Operator2Arg extends Operator1Arg{
    public Wyrazenie arg2;

}
