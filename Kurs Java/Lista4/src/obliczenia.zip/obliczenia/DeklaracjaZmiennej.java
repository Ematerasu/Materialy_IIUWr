package obliczenia;
import struktury.*;

public class DeklaracjaZmiennej extends Instrukcja {

    private double value;
    private String name;

    public DeklaracjaZmiennej(String k) {
        this.name = k;
        this.value = 0.0;
    }

    @Override
    public void wykonaj() {
        Zmienna.zbiorZmiennych.Wstaw(new Para(this.name, this.value));
    }

    @Override
    public String toString() {
        return "var " + this.name+";\n";
    }
}
